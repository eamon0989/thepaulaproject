A Pen created at CodePen.io. You can find this one at http://codepen.io/marijoha/pen/zKjvEw.

 Select dropdown - styled and filterable using HTML, CSS and vanilla JS. Works using a input field to grab the value from the dropdown list. 